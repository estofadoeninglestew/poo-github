/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Repartidor extends Empleado{

    //ATRIBUTOS
    private boolean disponible;
    private String estadoUnidad;
    
    //CONSTRUCTOR
    public Repartidor(String DNI, String Nombres, String Apellidos, String Usuario, String Password) {
        super(DNI, Nombres, Apellidos, Usuario, Password);
        this.disponible = true;
        this.estadoUnidad = "Operativa"; //Se asume porque es recien contratado
    }

    //GETTERS & SETTERS
    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public String getEstadoUnidad() {
        return estadoUnidad;
    }

    public void setEstadoUnidad(String estadoUnidad) {
        this.estadoUnidad = estadoUnidad;
    }
    
    
    //Del metodo abstracto
    @Override
    public String obtenerRol() {
        return "Repartidor";
    }

    @Override
    public String VerInfo() {
        return super.VerInfo() + 
                "\nRol: " + obtenerRol(); 
    }
    
    
    
}
