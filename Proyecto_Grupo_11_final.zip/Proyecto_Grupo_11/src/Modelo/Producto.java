    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Producto {
    
    //ATRIBUTOS
    private String Codigo;
    private String NombreDescriptivo;
    private double PrecioBase;
    private String Categoria;
    private int Stock;
    private boolean Disponible;
    
    //METODO ==CONSTRUCTOR==
    public Producto(String Codigo, String NombreDescriptivo, double PrecioBase, String Categoria, int Stock, boolean Disponible) {
        this.Codigo = Codigo;
        this.NombreDescriptivo = NombreDescriptivo;
        this.PrecioBase = PrecioBase;
        this.Categoria = Categoria;
        this.Stock = Stock;
        this.Disponible = Disponible;
    }
    
    //GETTERS & SETTERS
    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombreDescriptivo() {
        return NombreDescriptivo;
    }

    public void setNombreDescriptivo(String NombreDescriptivo) {
        this.NombreDescriptivo = NombreDescriptivo;
    }

    public double getPrecioBase() {
        return PrecioBase;
    }

    public void setPrecioBase(double PrecioBase) {
        this.PrecioBase = PrecioBase;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public boolean isDisponible() {
        return Disponible;
    }

    public void setDisponible(boolean Disponible) {
        this.Disponible = Disponible;
    }
    
    //METODO VERINFO
    public String VerInfo() {
        return "Codigo: " + Codigo + 
                "\nNombre Descriptivo: " + NombreDescriptivo + 
                "\nPrecio Base: " + PrecioBase + 
                "\nCategoria: " + Categoria + 
                "\nStock: " + Stock + 
                "\nDisponible: " + Disponible;
    }
    
    
}
