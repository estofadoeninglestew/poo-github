/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class ComboEspecial {
    
    //ATRIBUTOS
    private String Nombre;
    private String Descripcion;
    private double PrecioPromocional;
    
    //ATRIBUTO DE ARREGLO PARA LISTA DE PRODUCTOS
    // ComboEspecial 1 ---- 1..* productos
    private Producto[] listaProducto;
    private int contadorProductos;
    
    //METODO ==CONSTRUCTOR==
    public ComboEspecial(String Nombre, String Descripcion, double PrecioPromocional) {
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.PrecioPromocional = PrecioPromocional;
        
        this.listaProducto = new Producto[10];
        this.contadorProductos = 0;
    }
    
    //GETTERS & SETTERS
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public double getPrecioPromocional() {
        return PrecioPromocional;
    }

    public void setPrecioPromocional(double PrecioPromocional) {
        this.PrecioPromocional = PrecioPromocional;
    }

    public Producto[] getListaProducto() {
        return listaProducto;
    }

    public void setListaProducto(Producto[] listaProducto) {
        this.listaProducto = listaProducto;
    }

    public int getContadorProductos() {
        return contadorProductos;
    }

    public void setContadorProductos(int contadorProductos) {
        this.contadorProductos = contadorProductos;
    }
    
    
    //METODO VERINFO
    public String VerInfo() {
        return "Nombre: " + Nombre + 
                "\nDescripcion: " + Descripcion + 
                "\nPrecio Promocional: " + PrecioPromocional;
    }
    
    
    //METODO PARA INGRESAR PRODUDCTOS
    public void AgregarProducto(Producto producto)
    {
        if(this.contadorProductos < this.listaProducto.length)
        {
            this.listaProducto[this.contadorProductos] = producto;
            this.contadorProductos++;
        }
    }
}
