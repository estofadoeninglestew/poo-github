/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Pedido 
{
    //CONTASTE PARA TODOS LOS PEDIDOS
    private static final double PORCENTAJE_IGV = 0.18;
    
    //ATRIBUTOS
    private int NumeroCorrelativo;
    private String TipoEntrega;
    private String Estado;
    private double RecargoDelivery;
    private double igv;
    
    private DetallePedido[] listaDetalles;
    private int contadorDetalles;
    
    private double subtotal;
    private double total;
    
    private Cliente cliente; //Pedido guardará un cliente
    // cliente 1 ---- 1..* Pedidos
    
    private Repartidor repartidor; //Se asigna despues, cuando el pedido
    //pasa a estado envio
    
    private Cajero cajero;
    private String fecha;
    
    
    //METODO ==CONSTRUCTOR==
    public Pedido(int NumeroCorrelativo, Cliente cliente, Cajero cajero, String fecha, String TipoEntrega, 
            String Estado, double RecargoDelivery) {
        this.NumeroCorrelativo = NumeroCorrelativo;
        this.cliente = cliente;
        this.cajero = cajero;
        this.fecha = fecha;
        
        this.TipoEntrega = TipoEntrega;
        this.Estado = Estado;
        this.RecargoDelivery = RecargoDelivery;
        
        this.listaDetalles = new DetallePedido[50];
        this.contadorDetalles = 0;
        
        
        this.subtotal = 0;
        this.total = 0;
        this.igv = 0;
    }
    
    
    //GETTERS & SETTERS
    public int getNumeroCorrelativo() {
        return NumeroCorrelativo;
    }

    public void setNumeroCorrelativo(int NumeroCorrelativo) {
        this.NumeroCorrelativo = NumeroCorrelativo;
    }

    public String getTipoEntrega() {
        return TipoEntrega;
    }

    public void setTipoEntrega(String TipoEntrega) {
        this.TipoEntrega = TipoEntrega;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public double getRecargoDelivery() {
        return RecargoDelivery;
    }

    public void setRecargoDelivery(double RecargoDelivery) {
        this.RecargoDelivery = RecargoDelivery;
    }

    public DetallePedido[] getListaDetalles() {
        return listaDetalles;
    }

    public void setListaDetalles(DetallePedido[] listaDetalles) {
        this.listaDetalles = listaDetalles;
    }

    public int getContadorDetalles() {
        return contadorDetalles;
    }

    public void setContadorDetalles(int contadorDetalles) {
        this.contadorDetalles = contadorDetalles;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Repartidor getRepartidor() {
        return repartidor;
    }

    public void setRepartidor(Repartidor repartidor) {
        this.repartidor = repartidor;
    }

    public double getIgv() {
        return igv;
    }

    public Cajero getCajero() {
        return cajero;
    }

    public void setCajero(Cajero cajero) {
        this.cajero = cajero;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
    
    
    //METODO CALCULARSUBTOTAL
    public double CalcularSubTotal()
    {
        subtotal = 0;
        
        for(int i=0; i<this.contadorDetalles;i++)
        {
            this.subtotal += this.listaDetalles[i].getSubtotal();
        }
        return this.subtotal;
    }
    
    //METODO CALCULARTOTAL
    public double CalcularTotal()
    {
        double valorVenta = this.CalcularSubTotal() + this.RecargoDelivery;
        this.igv = valorVenta * PORCENTAJE_IGV;
        this.total = valorVenta + this.igv;
        return this.total;
    }
    
    
    //METODO AGREGAR DETALLE
    public void AgregarDetalle(DetallePedido detalle)
    {
        if(this.contadorDetalles < this.listaDetalles.length)
        {
            this.listaDetalles[this.contadorDetalles] = detalle;
            this.contadorDetalles++;
        }
    }
    
    //METODO DE ELIMINAR DETALLE
    
public void EliminarDetalle(int posicion)
{
    if (posicion >= 0 && posicion < this.contadorDetalles)
    {
        for (int j = posicion; j < this.contadorDetalles - 1; j++)
        {
            this.listaDetalles[j] = this.listaDetalles[j + 1];
        }
        this.listaDetalles[this.contadorDetalles - 1] = null;
        this.contadorDetalles--;
    }
}
}
