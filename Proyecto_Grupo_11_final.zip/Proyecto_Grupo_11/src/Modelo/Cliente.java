/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Cliente {
    
    //ATRIBUTOS
    private String TipoDocumento; //DNI o RUC
    private String NumeroDocumento;
    private String NombreCliente;
    private String TelefonoContacto;
    private String DireccionEntrega;
    
    //METODO ==CONSTRUCTOR==
    public Cliente(String TipoDocumento, String NumeroDocumento, String NombreCliente, String TelefonoContacto, String DireccionEntrega) {
        this.TipoDocumento = TipoDocumento;
        this.NumeroDocumento = NumeroDocumento;
        this.NombreCliente = NombreCliente;
        this.TelefonoContacto = TelefonoContacto;
        this.DireccionEntrega = DireccionEntrega;
    }
    
    
    //GETTERS & SETTERS
    public String getTipoDocumento() {
        return TipoDocumento;
    }

    public void setTipoDocumento(String TipoDocumento) {
        this.TipoDocumento = TipoDocumento;
    }

    public String getNumeroDocumento() {
        return NumeroDocumento;
    }

    public void setNumeroDocumento(String NumeroDocumento) {
        this.NumeroDocumento = NumeroDocumento;
    }

    public String getNombreCliente() {
        return NombreCliente;
    }

    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public String getTelefonoContacto() {
        return TelefonoContacto;
    }

    public void setTelefonoContacto(String TelefonoContacto) {
        this.TelefonoContacto = TelefonoContacto;
    }

    public String getDireccionEntrega() {
        return DireccionEntrega;
    }

    public void setDireccionEntrega(String DireccionEntrega) {
        this.DireccionEntrega = DireccionEntrega;
    }
    
    
    //METODO VERINFO
    public String VerInfo() {
        return "Tipo Documento: " + TipoDocumento + 
                "\nNumero: " + NumeroDocumento + 
                "\nNombre del Cliente:" + NombreCliente + 
                "\nTelefono de Contacto: " + TelefonoContacto + 
                "\nDireccion de Entrega=" + DireccionEntrega;
    }
    
    
    
    
    
}


