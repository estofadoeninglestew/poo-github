/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Cajero extends Empleado{

    //CONSTRUCTOR
    public Cajero(String DNI, String Nombres, String Apellidos, String Usuario, String Password) {
        super(DNI, Nombres, Apellidos, Usuario, Password);
    }

    @Override
    public String obtenerRol() {
        return "Cajero";
    }

    @Override
    public String VerInfo() {
        return super.VerInfo() + 
                "\nRol: " + obtenerRol(); 
    }
    
    
    
}
