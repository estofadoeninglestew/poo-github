/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public abstract class Empleado {
    
    //ATRIBUTOS
    protected String DNI;
    protected String Nombres;
    protected String Apellidos;
    protected String Usuario;
    protected String Password;
    
    //METODO ==CONSTRUCTOR==
    public Empleado(String DNI, String Nombres, String Apellidos, String Usuario, String Password) {
        this.DNI = DNI;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
        this.Usuario = Usuario;
        this.Password = Password;
    }
    
    //GETTERS & SETTERS
    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    //METODO VERINFO
    public String VerInfo() {
        return "DNI: " + DNI + 
                "\nNombres: " + Nombres + 
                "\nApellidos: " + Apellidos + 
                "\nUsuario: " + Usuario;
    }
    
    
    //METODO ABSTRACTO
    public abstract String obtenerRol();
    
}
