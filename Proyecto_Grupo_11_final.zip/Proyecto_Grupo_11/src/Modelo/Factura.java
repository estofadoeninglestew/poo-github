/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class Factura {
    
    //ATRIBUTOS
    private int Numero;
    private String TipoComprobante;
    private double SubTotal;
    private double Total;
    private double IGV;
    
    private Pedido pedido; //Factura a que pedido pertenece
    
    //METODO ==CONSTRUCTOR==
    public Factura(int Numero, Pedido pedido, String TipoComprobante, double SubTotal, double IGV, double Total) {
        this.Numero = Numero;
        this.pedido = pedido;
        this.TipoComprobante = TipoComprobante;
        this.SubTotal = SubTotal;
        this.IGV = IGV;
        this.Total = Total;
    }
    
    
    //GETTERS & SETTERS
    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public String getTipoComprobante() {
        return TipoComprobante;
    }

    public void setTipoComprobante(String TipoComprobante) {
        this.TipoComprobante = TipoComprobante;
    }

    public double getSubTotal() {
        return SubTotal;
    }

    public void setSubTotal(double SubTotal) {
        this.SubTotal = SubTotal;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public double getIGV() {
        return IGV;
    }

    public void setIGV(double IGV) {
        this.IGV = IGV;
    }
    
    
    
    
    //Metodo VerInfo
    public String VerInfo() {
        return "Numero: " + Numero + 
                "\nTipo de Comprobante: " + TipoComprobante + 
                "\nSubTotal: " + SubTotal + 
                "\nIGV: " + IGV +
                "\nTotal: " + Total;
    }
    
    
    
}
