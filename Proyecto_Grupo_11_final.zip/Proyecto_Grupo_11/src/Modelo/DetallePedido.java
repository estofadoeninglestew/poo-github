/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Angel
 */
public class DetallePedido {
    
    //ATRIBUTOS
    private boolean esCombo;
    private int cantidad;
    private double precioUnitario;
    private double subtotal;
    private ComboEspecial combo; //Un combo no es un producto
    
    private Producto producto;
    
    //METODO ==CONSTRUCTOR==
    public DetallePedido(Producto producto, int cantidad, double precioUnitario, 
            double subtotal, boolean esCombo) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.subtotal = subtotal;
        this.esCombo = esCombo;
    }
    
    //MISMO CONSTRUCTOR (SOBRECARGA), cuando el detalle sea un combo
    public DetallePedido(ComboEspecial combo, int cantidad, double precioUnitario, double subtotal, boolean esCombo) {
        this.combo = combo;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.subtotal = subtotal;
        this.esCombo = esCombo;
    }
    
    //GETTERS & SETTERS
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public boolean isEsCombo() {
        return esCombo;
    }

    public void setEsCombo(boolean esCombo) {
        this.esCombo = esCombo;
    }

    public ComboEspecial getCombo() {
        return combo;
    }

    public void setCombo(ComboEspecial combo) {
        this.combo = combo;
    }
    
    
    //METODO Calcular SUBTOTAL
    public double CalcularSubTotal()
    {
        this.subtotal = cantidad * precioUnitario;
        return this.subtotal;
    }
    
    
    //METODO VERINFO
    public String VerInfo() {
        return "Cantidad: " + cantidad + 
                "\nPrecio Unitario: " + precioUnitario + 
                "\nSubtotal: " + subtotal;
    }
    
    
    //METODO PARA EL GUI, sepa saber quien es.
    public String getNombreItem() 
    {
        if (this.esCombo && this.combo != null) 
        {
            return this.combo.getNombre();
        } 
        
        else if (this.producto != null) 
        {
            return this.producto.getNombreDescriptivo();
        }
        return "Desconocido";
    }   
    
}
