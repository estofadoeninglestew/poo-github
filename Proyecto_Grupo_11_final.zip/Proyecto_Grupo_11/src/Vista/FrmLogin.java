/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;
import Gestion.GestionClientes;
import Gestion.GestionCombosEspeciales;
import Gestion.GestionEmpleados;
import Gestion.GestionPedidos;
import Gestion.GestionProductos;
import Modelo.Administrador;
import Modelo.Cajero;
import Modelo.Cliente;
import Modelo.Empleado;
import Modelo.Producto;
import Modelo.Repartidor;


import javax.swing.JOptionPane;

/**
 *
 * @author Angel
 */
public class FrmLogin extends javax.swing.JFrame {
    
    //COMPARTIMOS C/D OBJETO
    private GestionEmpleados gestionEmpleado; //Atributo/Objeto creado
    private GestionProductos gestionProducto;
    private GestionClientes gestionCliente;
    private GestionCombosEspeciales gestionCombo;
    private GestionPedidos gestionPedido;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmLogin.class.getName());

    /**
     * Creates new form FrmLogin
     */
    //CONSTRUCTOR
    public FrmLogin() {
        initComponents();
        gestionEmpleado = new GestionEmpleados();
        gestionProducto = new GestionProductos();
        gestionCliente = new GestionClientes();
        gestionCombo = new GestionCombosEspeciales();
        gestionPedido = new GestionPedidos();
        
        //METODO PRUEBA
        Administrador admin = new Administrador(
                "12345678", "Angel", "Sologurre", "admin", "1234");
        gestionEmpleado.RegistrarEmpleado(admin);
        
        Cajero caje = new Cajero("12345678", "Sebas", "Yagamuchi", "admin", "12345");
        gestionEmpleado.RegistrarEmpleado(caje);
        
        //DATOS CON MAS PRUIEBAS
        Repartidor rep = new Repartidor("22222222", "Royer", "Test", "repartidor", "1234");
        gestionEmpleado.RegistrarEmpleado(rep);

        Producto product = new Producto("P001", "Hamburguesa", 15.90, "Hamburguesas", 50, true);
        gestionProducto.RegistrarProducto(product);

        Cliente client = new Cliente("DNI", "99999999", "Cliente Test", "999999999", "Av. Test 123");
        gestionCliente.RegistrarCliente(client);
        
    }
    
    
    //METODO PARA PASAR OBJETOS A GESTIONPEDIDOS(para que no se borren al cerrar sesion)
    public FrmLogin(GestionEmpleados gestionEmpleado, GestionProductos gestionProducto,
        GestionClientes gestionCliente, GestionCombosEspeciales gestionCombo, GestionPedidos gestionPedido) 
    {

        initComponents();
        this.gestionEmpleado = gestionEmpleado;
        this.gestionProducto = gestionProducto;
        this.gestionCliente = gestionCliente;
        this.gestionCombo = gestionCombo;
        this.gestionPedido = gestionPedido;

    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        btnIngresar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("USUARIO");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("CONTRASEÑA");

        txtUsuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtUsuario.addActionListener(this::txtUsuarioActionPerformed);

        txtPassword.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtPassword.addActionListener(this::txtPasswordActionPerformed);

        btnIngresar.setBackground(new java.awt.Color(255, 204, 0));
        btnIngresar.setText("INGRESAR");
        btnIngresar.addActionListener(this::btnIngresarActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("INICIAR SESIÓN");

        btnSalir.setText("SALIR");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(248, 248, 248)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel2))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtUsuario)
                                        .addComponent(txtPassword)
                                        .addComponent(jLabel3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(53, 53, 53)
                                        .addComponent(jLabel1))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(300, 300, 300)
                                .addComponent(btnIngresar)))
                        .addGap(0, 259, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSalir)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalir)
                .addGap(31, 31, 31)
                .addComponent(jLabel3)
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(btnIngresar)
                .addGap(83, 83, 83))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        // TODO add your handling code here:
        
        String usuario = txtUsuario.getText();
        String password = new String(txtPassword.getPassword());
        
        Empleado empleadoLogueado = this.gestionEmpleado.validarLogin(usuario, password);
        
        if(empleadoLogueado != null)
        {
            FrmMenuPrincipal menu = new FrmMenuPrincipal(empleadoLogueado, gestionEmpleado, 
                    gestionProducto, gestionCliente, gestionCombo, gestionPedido);
            menu.setVisible(true); //venta nueva
            this.dispose(); //cierra la ventana de login
        }
        else
        {
            JOptionPane.showMessageDialog(this, 
                    "Usuario o contraseña incorrectos",
                    "Error de acceso", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmLogin().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
