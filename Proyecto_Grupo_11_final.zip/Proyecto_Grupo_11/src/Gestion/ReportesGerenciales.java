/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import Interfaces.Reportable;
import Modelo.Empleado;
import Modelo.Cajero;
import Modelo.Repartidor;
import Modelo.Pedido;
import Modelo.DetallePedido;

/**
 *
 * @author Angel
 */
public class ReportesGerenciales implements Reportable
{
    //ATRIBUTOS
    private GestionPedidos gestionPedidos;
    private GestionEmpleados gestionEmpleados;
    
    private String FechaInicio;
    private String FechaFin;

    public ReportesGerenciales(String FechaInicio, String FechaFin,
            GestionPedidos gestionPedidos, GestionEmpleados gestionEmpleados) {
        this.FechaInicio = FechaInicio;
        this.FechaFin = FechaFin;
        this.gestionPedidos = gestionPedidos;
        this.gestionEmpleados = gestionEmpleados;
    }

    public String getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(String FechaInicio) {
        this.FechaInicio = FechaInicio;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String FechaFin) {
        this.FechaFin = FechaFin;
    }
    
    
    //METODOS
    public String GenerarReporteProductividad()
    {
        String reporte = "REPORTE DE PRODUCTIVIDAD\n";
        
        Empleado[] empleados = this.gestionEmpleados.getListaEmpleados(); //para tener la lista completa
        int totalEmpleados = this.gestionEmpleados.getContador(); //contador
        
        Pedido[] pedidos = this.gestionPedidos.getListaPedidos(); //para tener la lista completa
        int totalPedidos = this.gestionPedidos.getContador(); //contador
        
        //Recorrido para verificar que clase es cada uno
        for(int i = 0; i< totalEmpleados; i++)
        {
            Empleado empleado = empleados[i];
            
            if(empleado instanceof Cajero)
            {
                int pedidosAtendidos = 0;
                
                for (int j = 0; j < totalPedidos; j++)
                {
                    if (pedidos[j].getCajero() == empleado)
                    {
                        pedidosAtendidos++;
                    }
                }
                
                reporte += empleado.getNombres() + " " + empleado.getApellidos() + 
                    " (Cajero) - Pedidos atendidos: " + pedidosAtendidos + "\n";
            
            }
            else if (empleado instanceof Repartidor)
            {
                int entregasRealizadas = 0;
                
                for(int j = 0; j < totalPedidos; j++)
                {
                    if (pedidos[j].getRepartidor() == empleado && pedidos[j].getEstado().equalsIgnoreCase("Entregado"))
                    {
                        entregasRealizadas++;
                    }
                }
                
                reporte += empleado.getNombres() + " " + empleado.getApellidos() + 
                    " (Repartidor) - Entregas atendidos: " + entregasRealizadas + "\n";
            }      
        }
        
        return reporte;
        
    }
    
    public String GenerarReporteIngresos()
    {
        double totalMenuRegular = 0;
        double totalCombos = 0;
        
        Pedido[] pedidos = this.gestionPedidos.getListaPedidos();
        int totalPedidos = this.gestionPedidos.getContador();
        
        for (int i = 0; i < totalPedidos; i++)
        {
            Pedido pedido = pedidos[i];
                        
            if (pedido.getFecha().equalsIgnoreCase(this.FechaInicio) && 
                    pedido.getFecha().equalsIgnoreCase(this.FechaFin))
            {
                DetallePedido[] detalles = pedido.getListaDetalles();
                
                for(int j = 0; j < pedido.getContadorDetalles(); j++)
                {
                    if(detalles[j].isEsCombo())
                    {
                        totalCombos += detalles[j].getSubtotal();
                    }
                    else
                    {
                        totalMenuRegular += detalles[j].getSubtotal();
                    }
                }
            }
                    
        }
        
        return "Reporte de Ingresos (" + this.FechaInicio + "a " + this.FechaFin + ")\n" + 
                "Ingresos por producto regular: S/ " + totalMenuRegular + "\n" +
                "Ingresos por combos promocionales: S/ " + totalCombos + "\n" + 
                "Total: S/ " + (totalMenuRegular + totalCombos);
        
    }
    
    //Implementacion de la interfaz
    @Override
    public void GenerarReporte() 
    {
        System.out.println(GenerarReporteProductividad());
        System.out.println(GenerarReporteIngresos());
        
    }
    
}
