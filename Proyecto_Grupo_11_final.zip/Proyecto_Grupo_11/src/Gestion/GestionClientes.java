/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import Modelo.Cliente;

/**
 *
 * @author Angel
 */
public class GestionClientes {
    
    //ATRIBUTOS
    private Cliente[] listaClientes;
    private int contador;
    
    
    //METODO ==CONSTRUCTOR==
    public GestionClientes() 
    {
        this.listaClientes = new Cliente[100];
        this.contador = 0;
    }
    
    
    //GETTERS & SETTERS
    public Cliente[] getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(Cliente[] listaClientes) {
        this.listaClientes = listaClientes;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    //METODO REGISTRAR CLIENTES
    public void RegistrarCliente(Cliente cliente)
    {
        if (this.contador < this.listaClientes.length)
        {
            this.listaClientes[this.contador] = cliente;
            this.contador++;
        }
        else
        {
            System.out.println("No hay espacio para más clientes.");
        }
    }
    
    //METODO MODIFICAR CLIENTE
    public boolean ModificarCliente(String TipoDocumento, String NumeroDocumento, String NombreCliente,
            String TelefonoContacto, String DireccionEntrega)
    {
        
        for (int i = 0; i<this.contador; i++)
        {
            
            if (this.listaClientes[i].getNumeroDocumento().equalsIgnoreCase(NumeroDocumento))
            {
                
                this.listaClientes[i].setTipoDocumento(TipoDocumento);
                this.listaClientes[i].setNombreCliente(NombreCliente);
                this.listaClientes[i].setTelefonoContacto(TelefonoContacto);
                this.listaClientes[i].setDireccionEntrega(DireccionEntrega);
                return true;
                
            }
        }
        
        return false;
    }
    
    
    //METODO ELIMINAR CLIENTES
    public boolean EliminarCliente(String NumeroDocumento)
    {
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaClientes[i].getNumeroDocumento().equalsIgnoreCase(NumeroDocumento))
            {
                for (int j=i; j< this.contador-1; j++)
                {
                    this.listaClientes[j] = this.listaClientes[j+1];
                }
                
                this.listaClientes[this.contador-1] = null;
                this.contador--;
                
                return true;
            }
        }
        
        return false;
        
    }
    
    //METODO BUSCAR CLIENTE
    public Cliente BuscarCliente(String NumeroDocumento)
    {
        
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaClientes[i].getNumeroDocumento().equalsIgnoreCase(NumeroDocumento))
            {
                return this.listaClientes[i];
            }
        }
        
        return null;
    }


    
}
