/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import Modelo.ComboEspecial;

/**
 *
 * @author Angel
 */
public class GestionCombosEspeciales 
{
    
    //ATRIBUTOS
    private ComboEspecial[] ListaCombosEspeciales;
    private int contador;
    
    //METODO ==CONSTRUCTOR==
    public GestionCombosEspeciales() 
    {
        this.ListaCombosEspeciales = new ComboEspecial[100];
        this.contador = 0;
    }
    
    //GETTERS & SETTERS
    public ComboEspecial[] getListaCombosEspeciales() {
        return ListaCombosEspeciales;
    }

    public void setListaCombosEspeciales(ComboEspecial[] ListaCombosEspeciales) {
        this.ListaCombosEspeciales = ListaCombosEspeciales;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    //METODO REGISTRAR COMBOSESPECIALES
    public void RegistrarComboEspecial(ComboEspecial ComboEspecial)
    {
        if (this.contador < this.ListaCombosEspeciales.length)
        {
            this.ListaCombosEspeciales[this.contador] = ComboEspecial;
            this.contador++;
        }
        else
        {
            System.out.println("No hay espacio para más Combos Especiales");
        }
    }
    
    //METODO MODIFICAR COMBOSESPECIALES
    public boolean ModificarComboEspecial(String Nombre, String Descripcion, double PrecioPromocional)
    {
        
        for (int i = 0; i<this.contador; i++)
        {
            
            if (this.ListaCombosEspeciales[i].getNombre().equalsIgnoreCase(Nombre))
            {
                
                this.ListaCombosEspeciales[i].setDescripcion(Descripcion);
                this.ListaCombosEspeciales[i].setPrecioPromocional(PrecioPromocional);
                
                return true;
                
            }
        }
        
        return false;
    }
    
    
    //METODO ELIMINAR COMBOSESPECIALES
    public boolean EliminarComboEspecial(String Nombre)
    {
        for (int i=0; i<this.contador; i++)
        {
            if (this.ListaCombosEspeciales[i].getNombre().equalsIgnoreCase(Nombre))
            {
                for (int j=i; j< this.contador-1; j++)
                {
                    this.ListaCombosEspeciales[j] = this.ListaCombosEspeciales[j+1];
                }
                
                this.ListaCombosEspeciales[this.contador-1] = null;
                this.contador--;
                
                return true;
            }
        }
        
        return false;
        
    }
    
    
    //METODO COMBOSESPECIALES
    public ComboEspecial BuscarComboEspecial(String Nombre)
    {
        
        for (int i=0; i<this.contador; i++)
        {
            if (this.ListaCombosEspeciales[i].getNombre().equalsIgnoreCase(Nombre))
            {
                return this.ListaCombosEspeciales[i];
            }
        }
        
        return null;
    }
    
    
}
