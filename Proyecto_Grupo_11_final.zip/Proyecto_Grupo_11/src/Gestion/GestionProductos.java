/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import Modelo.Producto;

/**
 *
 * @author Angel
 */
public class GestionProductos {
    
    //ATRIBUTOS
    private Producto[] listaProductos;
    private int contador;
    
    //METODO ==CONSTRUCTOR==
    public GestionProductos() 
    {
        this.listaProductos = new Producto[100];
        this.contador = 0;
    }
    
    //GETTERS & SETTERS
    public Producto[] getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(Producto[] listaProductos) {
        this.listaProductos = listaProductos;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    
    //METODO REGISTRAR PRODUCTOS
    public void RegistrarProducto(Producto producto)
    {
        if (this.contador < this.listaProductos.length)
        {
            this.listaProductos[this.contador] = producto;
            this.contador++;
        }
        else
        {
            System.out.println("No hay espacio para más productos.");
        }
    }
    
    //METODO MODIFICAR PRODUCTOS
    public boolean ModificarProducto(String codigo, String nombres, double precioBase,
            String categoria, int stock, boolean Disponible)
    {
        
        for (int i = 0; i<this.contador; i++)
        {
            
            if (this.listaProductos[i].getCodigo().equalsIgnoreCase(codigo))
            {
                
                this.listaProductos[i].setNombreDescriptivo(nombres);
                this.listaProductos[i].setPrecioBase(precioBase);
                this.listaProductos[i].setCategoria(categoria);
                this.listaProductos[i].setStock(stock);
                this.listaProductos[i].setDisponible(Disponible);
                
                return true;
                
            }
        }
        
        return false;
    }
    
    
    //METODO ELIMINAR PRODUCTOS
    public boolean EliminarProducto(String codigo)
    {
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaProductos[i].getCodigo().equalsIgnoreCase(codigo))
            {
                for (int j=i; j< this.contador-1; j++)
                {
                    this.listaProductos[j] = this.listaProductos[j+1];
                }
                
                this.listaProductos[this.contador-1] = null;
                this.contador--;
                
                return true;
            }
        }
        
        return false;
        
    }
    
    //METODO BUSCAR PRODUCTOS
    public Producto BuscarProducto(String codigo)
    {
        
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaProductos[i].getCodigo().equalsIgnoreCase(codigo))
            {
                return this.listaProductos[i];
            }
        }
        
        return null;
    }

    
    
}
