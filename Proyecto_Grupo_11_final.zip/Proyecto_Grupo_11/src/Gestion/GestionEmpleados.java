/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;
import Modelo.Empleado;

/**
 *
 * @author Angel
 */
public class GestionEmpleados {
    
    //ATRIBUTOS
    private Empleado[] listaEmpleados;
    private int contador;
    
    //METODO ==CONSTRUCTOR==
    public GestionEmpleados() 
    {
        this.listaEmpleados = new Empleado[100];
        contador = 0;
    }
    
    //GETTERS & SETTERS
    public Empleado[] getListaEmpleados() {
        return listaEmpleados;
    }

    public void setListaEmpleados(Empleado[] listaEmpleados) {
        this.listaEmpleados = listaEmpleados;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    //METODO REGISTRAR EMPLEADO
    public void RegistrarEmpleado(Empleado empleado)
    {
        if (this.contador < this.listaEmpleados.length)
        {
            this.listaEmpleados[this.contador] = empleado;
            this.contador++;
        }
        else
        {
            System.out.println("No hay espacio para más empleados.");
        }
    }
    
    //METODO MODIFICAR EMPLEADO
    public boolean ModificarEmpleado(String dni, String nombres, String apellidos,
            String usuario, String password)
    {
        
        for (int i = 0; i<this.contador; i++)
        {
            
            if (this.listaEmpleados[i].getDNI().equalsIgnoreCase(dni))
            {
                
                this.listaEmpleados[i].setNombres(nombres);
                this.listaEmpleados[i].setApellidos(apellidos);
                this.listaEmpleados[i].setUsuario(usuario);
                this.listaEmpleados[i].setPassword(password);
                
                return true;
                
            }
        }
        
        return false;
    }
    
    
    //METODO ELIMINAR EMPLEADO
    public boolean EliminarEmpleado(String dni)
    {
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaEmpleados[i].getDNI().equalsIgnoreCase(dni))
            {
                for (int j=i; j< this.contador-1; j++)
                {
                    this.listaEmpleados[j] = this.listaEmpleados[j+1];
                }
                
                this.listaEmpleados[this.contador-1] = null;
                this.contador--;
                
                return true;
            }
        }
        
        return false;
        
    }
    
    //METODO BUSCAREMPLEADO
    public Empleado BuscarEmpleado(String dni)
    {
        
        for (int i=0; i<this.contador; i++)
        {
            if (this.listaEmpleados[i].getDNI().equalsIgnoreCase(dni))
            {
                return this.listaEmpleados[i];
            }
        }
        
        return null;
    }
    
    //VALIDAR LOGIN DEL EMPLEADO
    public Empleado validarLogin(String usuario, String password)
    {
        for(int i=0;i<this.contador;i++)
        {
            if(this.listaEmpleados[i].getUsuario().equals(usuario)
               &&
               this.listaEmpleados[i].getPassword().equals(password))
            {
                return this.listaEmpleados[i];
            }
        }

        return null;
    }
    
}
