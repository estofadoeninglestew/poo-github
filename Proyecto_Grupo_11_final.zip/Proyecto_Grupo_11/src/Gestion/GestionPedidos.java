/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gestion;

import Modelo.Pedido;
import Modelo.DetallePedido;
import Modelo.Repartidor;
import java.util.HashSet;
import Modelo.ComboEspecial;
import Modelo.Producto;

/**
 *
 * @author Angel
 */
public class GestionPedidos 
{
    
    //ATRIBUTOS
    private Pedido[] listaPedidos;
    private int contador;
    
    
    //METODO ==CONSTRUCTOR==
    public GestionPedidos()
    {
        this.listaPedidos = new Pedido[100];
        this.contador = 0;
    }
    
    //GETTERS & SETTERS
    public Pedido[] getListaPedidos() {
        return listaPedidos;
    }

    public void setListaPedidos(Pedido[] listaPedidos) {
        this.listaPedidos = listaPedidos;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    //METODO CREAR PEDIDO
    public void CrearPedido(Pedido pedido)
    {
        if (this.contador < this.listaPedidos.length)
        {
            this.listaPedidos[this.contador] = pedido;
            this.contador++;
        }
        else
        {
            System.out.println("No hay espacio para más pedidos.");
        }
    }
    
    //METODO CAMBIAR ESTADO (LO LIBERA)
    public boolean CambiarEstado(int numeroPedido, String nuevoEstado)
    {
        for(int i=0; i<this.contador; i++)
            if(this.listaPedidos[i].getNumeroCorrelativo()== numeroPedido)
            {
                this.listaPedidos[i].setEstado(nuevoEstado);
                
                if(nuevoEstado.equalsIgnoreCase("Entregado") && this.listaPedidos[i].getRepartidor() != null)
                {
                    this.listaPedidos[i].getRepartidor().setDisponible(true);
                }
                
                return true;
            }
        
        return false;
    }
    
    //METODO BUSCAR PEDIDO
    public Pedido BuscarPedido(int numeroPedido)
    {
        for(int i=0; i<this.contador;i++)
        {
            if(this.listaPedidos[i].getNumeroCorrelativo() == numeroPedido)
            {
                return this.listaPedidos[i];
            }
        }
        
        return null;
    }
    
    
    public boolean VerificarStock(Pedido pedido)
    {
        for(int i = 0; i < pedido.getContadorDetalles(); i++)
        {
            DetallePedido detalle = pedido.getListaDetalles()[i];
            
            if (detalle.isEsCombo())
            {
                ComboEspecial combo = detalle.getCombo();
                Producto[] productoDelCombo = combo.getListaProducto();
                
                for (int j = 0; j < combo.getContadorProductos(); j++)
                {
                    if(productoDelCombo[j].getStock() < detalle.getCantidad())
                    {
                        return false;
                    }
                }
                
            }
            
            else
            {
                if (detalle.getProducto().getStock() < detalle.getCantidad())
                {
                    return false;
                }
            }

        }
        return true;
    }
    
    //METODO ASIGNAR REPARTIDOR (LO OCUPA)
    public boolean AsignarRepartidor(Pedido pedido, Repartidor repartidor)
    {
        if(repartidor.isDisponible() && repartidor.getEstadoUnidad().equalsIgnoreCase("Operativa"))
        {
            pedido.setRepartidor(repartidor);
            pedido.setEstado("En camino");
            repartidor.setDisponible(false); //cuando lleve pedido deja de estar libre
            return true;
        }
        return false;
    }
    
    
    
}
